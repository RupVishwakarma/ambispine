import React from 'react'

export default function Hero_Image() {
  return (
    <div className='' style={{marginTop:"80px"}}>
          <div className='text-end me-3 mt-4'>
          <img src="hero_4.jpg" className='img-fluid mt-4' height="700px" width="500px"  />
          </div>
      {/* <img src="hero_5.jpg" /> */}
    </div>
  )
}
